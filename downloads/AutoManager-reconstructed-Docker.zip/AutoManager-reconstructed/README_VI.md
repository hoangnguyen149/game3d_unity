# Auto Manager — bản vá thư mục dữ liệu

Tự tạo parent khi lưu Data/data.ini; ghi tệp tạm trước khi thay dữ liệu cũ.
Giữ nguyên working-directory-relative path và định dạng bản ghi.
7/7 kiểm thử filesystem đạt; build Docker thành công.
Có cả bản vá chọn tài khoản trước thao tác chạy/xóa.
Đóng bản cũ trước khi thay EXE. Không kèm game hoặc tài khoản.
EXE chưa được xác nhận lại trên Windows 11; 10 warning vẫn còn.
Báo cáo: https://github.com/hoangnguyen149/game3d_unity/blob/main/reports/STORAGE_FIX.md
Giới hạn source: https://github.com/hoangnguyen149/game3d_unity/blob/main/reconstruction/auto-manager/README_VI.md
