# Auto Manager — bản vá lựa chọn tài khoản

Đã sửa NullReference khi chưa chọn dòng trong hai nút chạy/xóa.
Build Docker thành công; 9/9 ca kiểm thử logic chọn tài khoản đạt.
EXE chưa được chạy xác nhận lại trên Windows 11; 10 warning compiler vẫn còn.
Đây là bản phục dựng, không phải mã gốc hoàn chỉnh. Gói không kèm game hay tài khoản.
Đóng bản cũ trước khi thay EXE; thêm và chọn một dòng tài khoản trước tác vụ.

Source và giới hạn: https://github.com/hoangnguyen149/game3d_unity/blob/main/reconstruction/auto-manager/README_VI.md
Báo cáo bản vá: https://github.com/hoangnguyen149/game3d_unity/blob/main/reports/SELECTION_FIX.md
