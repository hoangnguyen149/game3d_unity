Ban hop ngu x86 cua GameAssembly.dll, xuat tinh bang GNU objdump -d -M intel.
Day khong phai ma C# goc, khong phai project co the build.
Doi chieu dia chi voi script.json va dump.cs trong goi Mabu6sao-decompiled.zip.
Khong chay target khi phan tich.
GameAssembly.x86.asm SHA-256: 6a1f5495ce5680af102fd8d685fe4bc31dc3bfc7d515134b0049f7675e34f326
